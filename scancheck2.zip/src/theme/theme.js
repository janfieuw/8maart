import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#FDC500",
    },
  },
  shape: {
    borderRadius: 12,
  },
});